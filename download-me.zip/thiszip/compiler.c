#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

// Max. počet proměnných, které si program pamatuje
#define MAX_VARIABLES 100

typedef enum { TYPE_NUM, TYPE_STR } VarType;

typedef struct {
    char name[50];
    VarType type;
} Variable;

Variable symbol_table[MAX_VARIABLES];
int var_count = 0;

// Pomocná funkce pro zjištění typu proměnné
VarType get_variable_type(const char *name) {
    for (int i = 0; i < var_count; i++) {
        if (strcmp(symbol_table[i].name, name) == 0) {
            return symbol_table[i].type;
        }
    }
    return TYPE_NUM; // Výchozí (nebo error)
}

// Ořezání mezer
void trim(char *str) {
    char *p = str;
    int l = strlen(p);
    while(l > 0 && isspace((unsigned char)p[l - 1])) p[--l] = 0;
    while(*p && isspace((unsigned char)*p)) p++, l--;
    memmove(str, p, l + 1);
}

int has_solidus_extension(const char *filename) {
    int len = strlen(filename);
    if (len < 2) return 0;
    return (filename[len - 2] == '.' && filename[len - 1] == '/');
}

// HLAVNÍ KOMPILÁTOR: Převede Solidus na C
void compile_solidus(const char *input_filename, const char *output_c_filename) {
    FILE *in = fopen(input_filename, "r");
    FILE *out = fopen(output_c_filename, "w");
    if (!in || !out) {
        printf("[Solidus Error] Cannot open files!\n");
        exit(1);
    }

    // Vygenerujeme C hlavičku
    fprintf(out, "#include <stdio.h>\n#include <string.h>\n\n");
    
    // Buffer pro sběr funkcí (fun) a pro sběr main kódu
    char main_code[8192] = "";
    char line[256];
    
    while (fgets(line, sizeof(line), in)) {
        trim(line);
        if (strlen(line) == 0) continue;

        // 1. Detekce: var name = num [hodnota]
        char var_name[50];
        double num_val;
        if (sscanf(line, "var %s = num %lf", var_name, &num_val) == 2) {
            // Uložíme do tabulky symbolů
            strcpy(symbol_table[var_count].name, var_name);
            symbol_table[var_count].type = TYPE_NUM;
            var_count++;

            // Zapíšeme do main bufferu jako double
            char temp[100];
            sprintf(temp, "    double %s = %g;\n", var_name, num_val);
            strcat(main_code, temp);
            continue;
        }

        // 2. Detekce: var name = str "hodnota"
        char str_val[100];
        if (sscanf(line, "var %s = str \"%[^\"]\"", var_name, str_val) == 2) {
            strcpy(symbol_table[var_count].name, var_name);
            symbol_table[var_count].type = TYPE_STR;
            var_count++;

            char temp[200];
            sprintf(temp, "    char* %s = \"%s\";\n", var_name, str_val);
            strcat(main_code, temp);
            continue;
        }

        // 3. Detekce: print("...") s interpolací 'promenne'
        if (strncmp(line, "print(\"", 7) == 0) {
            char *start = strchr(line, '"') + 1;
            char *end = strrchr(line, '"');
            
            char fmt_string[500] = "    printf(\"";
            char args_string[500] = "";
            
            char *p = start;
            while (p < end) {
                if (*p == '\'') {
                    char *close_quote = strchr(p + 1, '\'');
                    if (close_quote && close_quote < end) {
                        char current_var[50];
                        int len = close_quote - (p + 1);
                        strncpy(current_var, p + 1, len);
                        current_var[len] = '\0';
                        
                        // Podíváme se do tabulky symbolů, jakého je typu!
                        VarType t = get_variable_type(current_var);
                        if (t == TYPE_STR) {
                            strcat(fmt_string, "%s");
                        } else {
                            strcat(fmt_string, "%g"); // Pro num (double)
                        }
                        
                        strcat(args_string, ", ");
                        strcat(args_string, current_var);
                        
                        p = close_quote + 1;
                        continue;
                    }
                }
                // Přidáme obyčejný znak
                int fmt_len = strlen(fmt_string);
                fmt_string[fmt_len] = *p;
                fmt_string[fmt_len + 1] = '\0';
                p++;
            }
            strcat(fmt_string, "\\n\"");
            strcat(fmt_string, args_string);
            strcat(fmt_string, ");\n");
            
            strcat(main_code, fmt_string);
            continue;
        }
        
        // 4. Detekce: fun jmeno() {
        if (strncmp(line, "fun ", 4) == 0) {
            char fun_name[50];
            if (sscanf(line, "fun %s", fun_name) == 1) {
                fprintf(out, "void %s\n", fun_name); // Generujeme funkci přímo do C hlavičky
                continue;
            }
        }
        
        // Obyčejné závorky nebo volání funkcí (např. pozdrav() nebo })
        if (strcmp(line, "}") == 0) {
            fprintf(out, "}\n\n");
        } else if (strchr(line, '(') && strchr(line, ')')) {
            // Volání funkce
            char temp[100];
            sprintf(temp, "    %s;\n", line);
            strcat(main_code, temp);
        }
    }

    // Na konec vygenerujeme schovaný main a vložíme do něj nashromážděný kód
    fprintf(out, "int main() {\n%s    return 0;\n}\n", main_code);

    fclose(in);
    fclose(out);
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage:\n  solidus run [file./]\n  solidus build [file./]\n");
        return 1;
    }

    char *command = argv[1];
    char *filename = argv[2];

    if (!has_solidus_extension(filename)) {
        printf("[Solidus Error] File must end with './'\n");
        return 1;
    }

    // Spustíme kompilaci do dočasného souboru _temp.c
    compile_solidus(filename, "_temp.c");

    if (strcmp(command, "build") == 0) {
        printf("[Solidus] Building native binary...\n");
        // Zkompilujeme vygenerované Cčko do výsledného spustitelného programu
        system("gcc _temp.c -o program");
        printf("[Solidus] Done! Created 'program'\n");
    } 
    else if (strcmp(command, "run") == 0) {
        // Buildneme a hned spustíme
        system("gcc _temp.c -o _temp_exec");
#ifdef _WIN32
        system("_temp_exec.exe");
#else
        system("./_temp_exec");
#endif
    }

    return 0;
}