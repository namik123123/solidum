@echo off
echo Installing Solidus programming language for Windows...

:: 1. Compile the compiler
gcc main.c -o solidus.exe

:: 2. Create a permanent directory on C: drive
if not exist "C:\Solidus" mkdir "C:\Solidus"

:: 3. Move the executable
move solidus.exe C:\Solidus\

:: 4. Add the directory to the User PATH environment variable
setx PATH "%PATH%;C:\Solidus"

echo Installation complete! Please open a new CMD window and type 'solidus'.
pause
