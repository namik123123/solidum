#!/bin/bash
echo "Installing Solidus programming language on macOS..."

# 1. Compile using Clang (macOS default compiler)
clang main.c -o solidus

# 2. Move the binary to global bin (requires sudo password)
sudo mv solidus /usr/local/bin/

echo "Installation complete! You can now use the 'solidus' command."
