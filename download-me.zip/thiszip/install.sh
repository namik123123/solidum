#!/bin/bash
echo "Installing Solidus programming language..."

# 1. Compile the compiler using GCC
gcc main.c -o solidus

# 2. Create local bin directory if it doesn't exist
mkdir -p ~/.local/bin

# 3. Move the binary to the local bin folder
mv solidus ~/.local/bin/

echo "Installation complete! Restart your terminal and type 'solidus' to start."
